import React, { useState } from 'react'

const Announcement = () => {

    // const [fontsize, setFontSize] = useState({})
    const [form, setForm] = useState({
        message:'',
        position:'',
        links:'',
        bgColorMsg: '',
        colorMsg:'',
        fontSize:'',
        fontStyling:'',
        fontWeight:'',
    });

    const handleChange = (event) =>{
        const {name, value} = event.target;
        setForm(prev =>{
            return{
                ...prev,
                [name] : value
            }
            // console.log(form);
        });
    }

    const handleClick = (event) =>{
        // document.body.classList.add('span')
    }

    console.log(form);
    // console.log(fontsize);
    return (
        <div className='content-wrapper'>
            <div className="display-content">
                {/* <span>Preview</span> */}
                
                <p style={{
                    background: form.bgColorMsg,
                    color: form.colorMsg,
                    fontSize: `${form.fontSize}px`,
                    fontStyle:form.fontStyling,
                    fontWeight: form.fontWeight,
                }}
                    className='content-bar'>
                        <span >{form.message}</span> <br />
                    </p>
            </div><br />
            <hr />
            <div className="form-container">
                <div className='message'>
                    <label htmlFor="">Message</label><br />
                    <input  type="text" id='message' name='message' value={form.message} onChange={handleChange}/>
                </div>
                <div className="bar-position">
                    <label htmlFor="">Bar Position</label><br />
                    <select name="position" value={form.position} id="" onChange={handleChange} >
                        <option value="top">On the Top of the Page</option>
                        <option className='bar-scrolling' value="sticky">On the Top of the Page, stick scrolling</option>
                        <option value="collection">Stay in the collection</option>
                    </select>
                </div>

                <div className="link-type">
                    <label htmlFor="">Link Type</label><br />
                    <select name="links" id="" value={form.links} onChange={handleChange}>
                        <option value="msg">For Meassage</option>
                        <option value="btn">For Button</option>
                        <option value="msg-btn">For Message and Button</option>
                    </select>
                </div>
                <div className="bar-radio-btn-wrapper">
                    <span>Announcement Bar</span><br />
                    <label htmlFor="">Static</label>
                    <input type="radio" value="" name='bar-btn' onClick={handleClick}/>
                    <label htmlFor="">Scroll</label>
                    <input type="radio" value="" name='bar-btn' onClick={handleClick}/>

                </div>
                <div className="color-picker">
                    <div>
                        <label for="">Background Color - Message</label><br />
                        <input type="color" id="" name="bgColorMsg" value={form.bgColorMsg} onChange={handleChange}/>
                    </div>
                    <div>
                        <label for="">Font Color - Message</label><br />
                        <input type="color" id="colorMsg" name="colorMsg" value={form.colorMsg} onChange={handleChange} />
                    </div>
                    <div>
                        <label for="favcolor">Background Color - Button</label><br />
                        <input type="color" id="favcolor" name="favcolor" value="#28E6E3" />
                    </div>
                    <div>
                        <label for="favcolor">Font Color - Button</label><br />
                        <input type="color" id="favcolor" name="favcolor" value="#7300FF" />
                    </div>
                </div>
                <div className="bar-font-styles">
                    <div>
                        <span className=''>Fonts</span> <br /><br />
                        <label htmlFor="">Font Size</label><br />
                        <input type="text" name='fontSize' value={form.fontSize} onChange={handleChange}/>
                        
                    </div>
                    <div>
                        <label htmlFor="">Font Style</label><br />
                        <select name="fontStyling" id="" value={form.fontStyling} onChange={handleChange} >
                            <option value="normal">Normal</option>
                            <option value="italic">Italic</option>
                            
                        </select>
                    </div>
                    <div>
                        <label htmlFor="">Font Weight</label><br />
                        <select name="fontWeight" id="" value={form.fontWeight} onChange={handleChange}>
                            <option value="normal">Normal</option>
                            <option value="bold">Bold</option>
                            <option value="lighter">Lighter</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
    );
};


export default Announcement;
