import React from 'react'

const about = () => {
  return (
    <div>

    </div>
  )
}

export default about

// const [fontsize, setFontSize] = useState({})
// const handleChange = (event) =>{
//     const {name, value} = event.target;
//     setForm(prev =>{
//         return{
//             ...prev,
//             [name] : value
//         }
//         // console.log(form);
//     });
//     setFontSize((prev) =>({
//             ...prev,
//             [name] : value,
        
//     }));
// }
// <input type="text" name='fontSize' value={fontsize} onChange={handleChange}/>
                        