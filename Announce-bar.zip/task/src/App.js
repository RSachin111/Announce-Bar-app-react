import './App.css';
import Announcement from './components/Announcement';
import About from './components/about';
function App() {
  return (
    <div className="App">
      <Announcement />
      <About/>
    </div>
  );
}

export default App;
